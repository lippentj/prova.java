public class TesteListener {
    public static void main(String[] args) {
        //new ExemploActionListener();
        //new ExemploActionClasseAnonima();
        //new ExemploMouseListener();
        //new ExemploMouseListener2();
        new ExemploMouseMotionListener();
    }
}
