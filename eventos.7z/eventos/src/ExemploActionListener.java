import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExemploActionListener implements ActionListener {//1*
    JTextField tf = new JTextField();
    JButton b = new JButton();

    public ExemploActionListener(){
        JFrame f = new JFrame("Exemplo de Action Lister");
        f.setSize(400,400);
        b.setText("clique aqui!!");

        b.addActionListener(this);//2*

        tf.setBounds(50,50,150,20);
        b.setBounds(50,100,100,30);

        f.add(tf);
        f.add(b);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        tf.setText("O botao foi clicado");
    }


}
