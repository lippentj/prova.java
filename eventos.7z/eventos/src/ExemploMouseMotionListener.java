import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class ExemploMouseMotionListener extends JFrame implements MouseMotionListener {
    public ExemploMouseMotionListener () {
        addMouseMotionListener(this);

        setSize(400,400);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        Graphics g = getGraphics();
        g.setColor(Color.black);
        g.fillOval(e.getX(),e.getY(),100,2);
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
